######################################################################
#
#   CS5706/MA5638
#   Lab 04 - Exploratory Data Analysis in R
#   Exercise: EDA and PCA
#   Alessandro Pandini
#
######################################################################
# 1. load data and summary statistics
### 1.1 load the data from the heptatlon.csv file and inspect it
###   the dataset is available also in the HSAUR package



### 1.2 get a summary report of the variables


### 1.3 remove the score variable from the dataset


### 1.4 calculate person correlation coefficient for the dataset


######################################################################
# 2. graphical analysis
### 2.1 create a vector s_variables of labels for:
###   hurdles, run200m, run800m


### 2.2 create a vector m_variables of labels for:
###   highjump, longjump, javelin


### 2.3 generate three simple boxplots for s_variables, m_variables and shot
###   display all three plots on one page







######################################################################
# 3. PCA
### 3.1 perform PCA on the dataset (without the score variable)


######################################################################
# 4. Visual analysis of PCA results
### 4.1 calculate the proportion of exaplained variance (PEV) from the std values



### 4.2 plot the cumulative PEV












### 4.3 get and inspect the loadings



### 4.4 generate a biplot for PC1 and PC2








